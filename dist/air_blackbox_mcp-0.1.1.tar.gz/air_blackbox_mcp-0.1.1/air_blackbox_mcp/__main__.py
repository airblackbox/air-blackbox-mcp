"""Allow running as: python -m air_blackbox_mcp"""
from . import main

main()
